﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudentProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Student s = new Student();
        LibraryDAL dal = new LibraryDAL();
        int id = Convert.ToInt32(Session["loginid"]);
        s =dal.FindStudent(id);
        lbl_userid.Text = s.StudentID.ToString();
        lbl_stname.Text = s.StudentName;
        lbl_email.Text = s.StudentEmailID;
        studentimage.ImageUrl = s.StudentImage;
    }
}