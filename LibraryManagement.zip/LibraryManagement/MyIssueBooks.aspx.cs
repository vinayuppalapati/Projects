﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyIssueBooks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Session["loginid"]);
        List<MyIssuedBooks> list = new List<MyIssuedBooks>();
        LibraryDAL dal = new LibraryDAL();
        list = dal.myissuebooks(id);
        gv.DataSource = list;
        gv.DataBind();
    }

    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}