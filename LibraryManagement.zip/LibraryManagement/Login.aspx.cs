﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session.Clear();
            ddl_usertype.Items.Add(new ListItem("", "Select"));
            ddl_usertype.Items.Add(new ListItem("Student", "Student"));
            ddl_usertype.Items.Add(new ListItem("Admin", "Admin"));
        }
    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        LibraryDAL dal = new LibraryDAL();
        if (ddl_usertype.Text == "Admin")
        {
           // bool status = dal.LoginStudent(Convert.ToInt32(txt_studentid.Text), txt_password.Text);
            if (txt_studentid.Text=="admin" && txt_password.Text=="admin")
            {
                Session["loginid"] = txt_studentid.Text;

                Response.Redirect("~/HomeAdmin.aspx");
            }
            else
            {
                lbl_invalid.Text = "Invalid User and Password";
            }

        }
        else
        {

            bool status = dal.LoginStudent(Convert.ToInt32(txt_studentid.Text), txt_password.Text);
            if (status)
            {
                Session["loginid"] = txt_studentid.Text;

                Response.Redirect("~/Home.aspx");
            }
            else
            {
                lbl_invalid.Text = "Invalid User and Password";
            }
        }
      
        
    }
}