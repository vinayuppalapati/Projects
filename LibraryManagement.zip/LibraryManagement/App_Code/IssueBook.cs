﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IssueBook
/// </summary>
public class IssueBook
{
   public int IssueID
    {
        get;
        set;
    }
    public int BookId
    {
        get;
        set;
    }
    public int StudentID { get; set; }

    public DateTime IssueDate { get; set; }

    public string IssueStatus { get; set; }

}