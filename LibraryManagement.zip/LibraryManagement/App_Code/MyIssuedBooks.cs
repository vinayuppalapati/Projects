﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for MyIssuedBooks
/// </summary>
public class MyIssuedBooks
{
    public string BookName { get; set; }
    public int BookID { get; set; }
    public string BookImage { get; set; }

    public int StudentID { get; set; }

    public int IssueID { get; set; }

    public DateTime IssueDate { get; set; }

}